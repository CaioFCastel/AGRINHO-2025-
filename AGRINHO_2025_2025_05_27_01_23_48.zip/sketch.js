// Variáveis principais (igual antes)
let stage = 0,
    irrigated = false,
    growTime = 0,
    planted = false;
let money = 55500,
    totalColhido = 0;
let clima = 'sol',
    climaTempo = 0,
    proximaChuva = 0;
let dia = true,
    diaTempo = 0;
let dronePosX = 0;

const tempoCrescimentoBase = 3;

let upgrades = {
    sensor:    { cost:100,  level:0, name:'Sensor de Umidade',     icon:'💧', max:10 },
    drone:     { cost:990,  level:0, name:'Drone Avançado',        icon:'🚁', max:10 },
    plantador: { cost:1090, level:0, name:'Plantador Automático',  icon:'🛠️', max:5  },
    adubo:     { cost:130,  level:0, name:'Adubo Enriquecido',    icon:'🌿', max:50 },
    trator:    { cost:600,  level:0, name:'Trator Turbo',          icon:'🚜', max:10 }
};

let imagensMilho = [],
    imagensTomate = [],
    imagensAlface = [],
    imagensCenoura = [];
let plantaSprites = {},
    plantaSelecionada = 'milho';

let droneFrames = [];

let btnUpgrades, btnPlantas;
let showUpgrades = false,
    showPlantas  = false;

function preload() {
    for (let i = 0; i < 3; i++) {
        imagensMilho.push(  loadImage(`milho_stage${i}.png`) );
        imagensTomate.push( loadImage(`tomate_stage${i}.png`) );
        imagensAlface.push( loadImage(`alface_stage${i}.png`) );
        imagensCenoura.push(loadImage(`cenoura_stage${i}.png`) );
    }

    plantaSprites = {
        milho:   imagensMilho,
        tomate:  imagensTomate,
        alface:  imagensAlface,
        cenoura: imagensCenoura
    };

    droneFrames.push(
        loadImage('drone0.png'),
        loadImage('drone1.png')
    );
}

function setup() {
    createCanvas(750, 480);
    textFont('Arial');

    btnUpgrades = { x: width - 380, y: 10,  w: 180, h: 30 };
    btnPlantas  = { x: width - 190, y: 10,  w: 180, h: 30 };

    changeClima();
}

function draw() {
    // Dia/noite
    diaTempo++;
    if (diaTempo > 1200) {
        dia = !dia;
        diaTempo = 0;
    }
    background(dia ? color(180,230,180) : color(30,30,80));
    fill(dia ? color(139,69,19) : color(80,50,30));
    rect(0, height - 100, width, 100);

    // Clima e chuva
    climaTempo++;
    if (climaTempo > proximaChuva) changeClima();
    if (clima === 'chuva') {
        spawnRain();
        drawRain();
    }

    // Crescimento automático
    if (planted) {
        drawPlanta();
        if (frameCount % 60 === 0 && stage < 2) {
            if (clima === 'chuva' || irrigated) {
                growTime++;
                let tc = max(1, tempoCrescimentoBase - upgrades.trator.level);
                if (growTime >= tc) {
                    stage++;
                    growTime = 0;
                    irrigated = false;
                }
            }
        }
    }

    // Drone e irrigação aérea
    if (upgrades.drone.level > 0) {
        moveDrone();
        drawDrone(dronePosX, height - 200);
        if (irrigated) {
            spawnWater();
            drawWater();
        }
    }

    // UI e menus
    drawUI();
    drawActionButtons();
    drawMenuButtons();
    if (showUpgrades) drawUpgradePanel();
    if (showPlantas)  drawPlantaPanel();
}

// --- Funções de desenho de planta, drone, etc iguais ---

function drawPlanta() {
    let imgs = plantaSprites[plantaSelecionada];
    let img  = imgs[stage];
    imageMode(CENTER);
    image(img, width/2, height - 100 - img.height/2);
}

function drawDrone(x, y) {
    let idx = floor(frameCount / 10) % droneFrames.length;
    imageMode(CENTER);
    image(droneFrames[idx], x, y);
}

function moveDrone() {
    dronePosX = (dronePosX + 2) % (width + 50) - 50;
}

// --- UI e interações ---

function drawUI() {
    fill(255);
    textSize(16);
    textAlign(LEFT);
    text(`🌤️ Clima: ${clima === 'chuva' ? 'Chuva' : 'Sol'}`, 20, 20);
    text(`🌓 ${dia ? 'Dia' : 'Noite'}`, 20, 40);
    text(`💰 R$ ${money}`, 20, 60);
    text(`🌽 Colhido: ${totalColhido}`, 20, 80);
    text(`🌿 Planta: ${plantaSelecionada.charAt(0).toUpperCase() + plantaSelecionada.slice(1)}`, 20, 120);
}

function drawActionButtons() {
    fill(0,150,0);
    rect(20, 380, 120, 40, 5);
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(16);
    text('Plantar', 80, 400);

    fill(0,100,255);
    rect(160, 380, 120, 40, 5);
    fill(255);
    text('Irrigar', 220, 400);

    if (stage === 2) {
        fill(255,165,0);
        rect(300, 380, 120, 40, 5);
        fill(0);
        text('Colher', 360, 400);
    }
}

function drawMenuButtons() {
    fill(100,100,250);
    rect(btnUpgrades.x, btnUpgrades.y, btnUpgrades.w, btnUpgrades.h, 5);
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(14);
    text(showUpgrades ? 'FECHAR' : 'UPGRADES',
          btnUpgrades.x + btnUpgrades.w/2,
          btnUpgrades.y + btnUpgrades.h/2);

    fill(0,180,0);
    rect(btnPlantas.x, btnPlantas.y, btnPlantas.w, btnPlantas.h, 5);
    fill(255);
    text(showPlantas ? 'FECHAR' : 'PLANTAS',
          btnPlantas.x + btnPlantas.w/2,
          btnPlantas.y + btnPlantas.h/2);
}

function drawUpgradePanel() {
    const x = btnUpgrades.x,
          y0 = btnUpgrades.y + btnUpgrades.h + 10;
    fill(0,0,100,200);
    rect(x, y0, btnUpgrades.w, Object.keys(upgrades).length*60 + 20, 10);
    fill(255);
    textSize(14);
    textAlign(LEFT);
    let y = y0 + 20;
    for (let k in upgrades) {
        let u = upgrades[k];
        text(`${u.icon} ${u.name}`, x+10, y+15);
        text(`Nível ${u.level}/${u.max}`, x+10, y+30);
        text(`R$${u.cost}`, x+10, y+45);
        y += 60;
    }
}

function drawPlantaPanel() {
    const x = btnPlantas.x,
          y0 = btnPlantas.y + btnPlantas.h + 10;
    fill(0,100,0,200);
    rect(x, y0, btnPlantas.w, Object.keys(plantaSprites).length*60 + 20, 10);
    fill(255);
    textSize(14);
    textAlign(LEFT);
    let y = y0 + 20;
    for (let key in plantaSprites) {
        let nome = key.charAt(0).toUpperCase() + key.slice(1);
        text(nome, x+10, y+15);
        y += 40;
    }
}

function spawnRain() {}
function drawRain() {}
function spawnWater() {}
function drawWater() {}

function changeClima() {
    climaTempo = 0;
    proximaChuva = random(200, 800);
    clima = random() < 0.3 ? 'chuva' : 'sol';
}

// ---- AÇÃO AO CLICAR ----
function mousePressed() {
    // Botão Upgrades
    if (
        mouseX > btnUpgrades.x && mouseX < btnUpgrades.x + btnUpgrades.w &&
        mouseY > btnUpgrades.y && mouseY < btnUpgrades.y + btnUpgrades.h
    ) {
        showUpgrades = !showUpgrades;
        showPlantas = false;
        return;
    }

    // Botão Plantas
    if (
        mouseX > btnPlantas.x && mouseX < btnPlantas.x + btnPlantas.w &&
        mouseY > btnPlantas.y && mouseY < btnPlantas.y + btnPlantas.h
    ) {
        showPlantas = !showPlantas;
        showUpgrades = false;
        return;
    }

    // Se menus abertos, clicar neles
    if (showUpgrades) {
        // Detecta qual upgrade clicou
        const x = btnUpgrades.x,
              y0 = btnUpgrades.y + btnUpgrades.h + 10;
        let y = y0 + 20;
        for (let k in upgrades) {
            if (mouseX > x && mouseX < x + btnUpgrades.w &&
                mouseY > y - 15 && mouseY < y + 15) {
                let u = upgrades[k];
                if (money >= u.cost && u.level < u.max) {
                    money -= u.cost;
                    u.level++;
                    u.cost = floor(u.cost * 1.5); // aumenta o preço do próximo upgrade
                }
                break;
            }
            y += 60;
        }
        return;
    }

    if (showPlantas) {
        // Detecta qual planta foi clicada
        const x = btnPlantas.x,
              y0 = btnPlantas.y + btnPlantas.h + 10;
        let y = y0 + 10;
        for (let key in plantaSprites) {
            if (mouseX > x && mouseX < x + btnPlantas.w &&
                mouseY > y && mouseY < y + 30) {
                plantaSelecionada = key;
                planted = false;    // reseta planta ao trocar
                stage = 0;
                growTime = 0;
                irrigated = false;
                break;
            }
            y += 40;
        }
        return;
    }

    // Botões Plantar, Irrigar, Colher
    if (mouseX > 20 && mouseX < 140 && mouseY > 380 && mouseY < 420) {
        // Plantar
        if (!planted) {
            planted = true;
            stage = 0;
            growTime = 0;
            irrigated = false;
        }
    } else if (mouseX > 160 && mouseX < 280 && mouseY > 380 && mouseY < 420) {
        // Irrigar
        if (planted && !irrigated) {
            irrigated = true;
        }
    } else if (stage === 2 && mouseX > 300 && mouseX < 420 && mouseY > 380 && mouseY < 420) {
        // Colher
        if (planted && stage === 2) {
            planted = false;
            totalColhido++;
            money += 1000;    // Exemplo valor colheita
            stage = 0;
            growTime = 0;
            irrigated = false;
        }
    }
}